#!/usr/bin/env bash
if [ -z "${BASH_VERSION:-}" ]; then
  exec bash "$0" "$@"
fi

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -d "$SCRIPT_DIR/app" ]]; then
  ROOT_DIR="$SCRIPT_DIR"
else
  ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"
fi
DEST_DIR="/var/www/bibleapp"

echo "Source project: $ROOT_DIR"
echo "Deployment destination: $DEST_DIR"

if [[ -d "$DEST_DIR" && "$ROOT_DIR" -ef "$DEST_DIR" ]]; then
  echo "Run this script from the source checkout or extracted release, not from the deployed scripts folder." >&2
  exit 1
fi

if [[ ! -d "$DEST_DIR" ]]; then
  echo "Destination directory does not exist: $DEST_DIR" >&2
  echo "Creating it..."
  sudo mkdir -p "$DEST_DIR"
fi
if ! command -v rsync >/dev/null 2>&1; then
  echo "rsync is required to remove stale deployed files safely. Install rsync and retry." >&2
  exit 1
fi

copy_file() {
  local src="$1"
  local dst="$2"

  if [[ ! -f "$src" ]]; then
    echo "Source file not found: $src" >&2
    return 1
  fi

  echo "Copying: $src -> $dst"
  sudo mkdir -p "$(dirname "$dst")"
  sudo cp "$src" "$dst"
}

sync_dir() {
  local src="$1"
  local dst="$2"

  if [[ ! -d "$src" ]]; then
    echo "Source directory not found: $src" >&2
    return 1
  fi

  echo "Synchronizing directory: $src -> $dst"
  sudo mkdir -p "$dst"
  if [[ "$src" == "$ROOT_DIR/app" ]]; then
    sudo rsync -a --delete --delete-excluded \
      --filter='H /data/book_order_leaderboard.json' \
      --filter='P /data/book_order_leaderboard.json' \
      --filter='H /data/.book_order_leaderboard.*.tmp' \
      --filter='P /data/.book_order_leaderboard.*.tmp' \
      --exclude='__pycache__/' \
      --exclude='*.pyc' \
      "$src"/ "$dst"/
  else
    sudo rsync -a --delete --delete-excluded \
      --exclude='__pycache__/' \
      --exclude='*.pyc' \
      "$src"/ "$dst"/
  fi
}

if [[ ! -f "$ROOT_DIR/app/templates/help.html" ]]; then
  echo "Source help page not found: $ROOT_DIR/app/templates/help.html" >&2
  exit 1
fi

echo "Removing obsolete flat-layout deployment files..."
sudo rm -rf -- "$DEST_DIR/templates" "$DEST_DIR/static"
sudo rm -f -- \
  "$DEST_DIR/main.py" \
  "$DEST_DIR/kjv.sqlite" \
  "$DEST_DIR/README.md" \
  "$DEST_DIR/requirements.txt" \
  "$DEST_DIR/icon.ico" \
  "$DEST_DIR/icon.png"

sync_dir "$ROOT_DIR/app" "$DEST_DIR/app"
sync_dir "$ROOT_DIR/config" "$DEST_DIR/config"
sync_dir "$ROOT_DIR/docs" "$DEST_DIR/docs"
sync_dir "$ROOT_DIR/packaging" "$DEST_DIR/packaging"

echo "Verifying deployed help page..."
if ! sudo cmp -s "$ROOT_DIR/app/templates/help.html" "$DEST_DIR/app/templates/help.html"; then
  echo "Deployed application help page does not match the source: $DEST_DIR/app/templates/help.html" >&2
  exit 1
fi
if [[ -e "$DEST_DIR/templates" ]]; then
  echo "Obsolete root-level templates directory remains: $DEST_DIR/templates" >&2
  exit 1
fi
echo "Deployed help page matches the source; obsolete root-level templates are removed."
sudo mkdir -p "$DEST_DIR/scripts"
copy_file "$SCRIPT_DIR/deploy_bibleapp.sh" "$DEST_DIR/deploy_bibleapp.sh"
copy_file "$SCRIPT_DIR/deploy_bibleapp.sh" "$DEST_DIR/scripts/deploy_bibleapp.sh"

echo "Stopping bibleapp service..."
sudo systemctl stop bibleapp

echo "Restarting bibleapp service..."
sudo systemctl start bibleapp

echo "Bible app deployed and restarted."
